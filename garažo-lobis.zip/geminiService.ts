
import { GoogleGenAI, Type } from "@google/genai";

export async function analyzePartImage(base64Image: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Analyze this image for a garage marketplace called "Garažo Lobis".
  Identify the part or tool. Return JSON data with:
  title, brand, category (from: Variklio dalys, Važiuoklė, Elektros sistema, Kėbulas, Interjeras, Ratai ir padangos, Apšvietimas, Įrankiai, Dirbtuvių įranga, Eksploatacinės medžiagos), 
  condition (Nauja, Kaip nauja, Gera, Naudota, Atrodo ne kaip, bet funkciją atlieka, Šlamštas), 
  suggestedPrice (number in EUR), description, partCode (if visible).
  Also suggest car compatibility if it's a car part.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: base64Image.split(',')[1] || base64Image } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            brand: { type: Type.STRING },
            category: { type: Type.STRING },
            condition: { type: Type.STRING },
            description: { type: Type.STRING },
            suggestedPrice: { type: Type.NUMBER },
            partCode: { type: Type.STRING },
            compatibility: {
              type: Type.OBJECT,
              properties: {
                brand: { type: Type.STRING },
                model: { type: Type.STRING }
              }
            }
          }
        }
      }
    });

    return JSON.parse(response.text);
  } catch (err) {
    console.error(err);
    throw err;
  }
}
